public class Movie {

    private String movieID, title, genre , boxOfficeRevenue;
    private int releaseYear;
    private double rating;

    public Movie(String movieID, String title, String genre, int releaseYear, double rating, String boxOfficeRevenue) {
        this.movieID = movieID;
        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;
        this.rating = rating;
        this.boxOfficeRevenue = boxOfficeRevenue;
    }

    public String getMovieID() {
        return movieID;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public double getRating() {
        return rating;
    }

    public String getBoxOfficeRevenue() {
        return boxOfficeRevenue;
    }
}

