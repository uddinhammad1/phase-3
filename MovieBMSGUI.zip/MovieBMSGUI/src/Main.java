import javax.swing.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.text.DecimalFormat;


public class Main extends JFrame{
    private ArrayList<Movie> movies = new ArrayList<>();
    private DefaultTableModel model;
    private JTable movieTable;

    public Main() {
        setTitle("Movie Database Management System");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create the table
        model = new DefaultTableModel(new String[]{"ID", "Title", "Genre", "Year", "Rating", "Revenue"}, 0);
        movieTable = new JTable(model);
        add(new JScrollPane(movieTable), BorderLayout.CENTER);

        // Add buttons
        JPanel panel = new JPanel();
        JButton addButton = new JButton("Add Movie");
        JButton removeButton = new JButton("Remove Movie");
        JButton batchUploadButton = new JButton("Batch Upload");
        JButton calculateButton = new JButton("Calculate Average Rating");
        panel.add(addButton);
        panel.add(removeButton);
        panel.add(batchUploadButton);
        panel.add(calculateButton);
        add(panel, BorderLayout.SOUTH);

        // Button actions
        addButton.addActionListener(e -> addMovieDialog());
        removeButton.addActionListener(e -> removeMovieDialog());
        batchUploadButton.addActionListener(e -> batchUploadMovies());
        calculateButton.addActionListener(e -> calculateAverageRating());

        setVisible(true);
    }

    private void addMovieDialog() {
        // Create dialog components
        JTextField idField = new JTextField(10);
        JTextField titleField = new JTextField(20);
        JTextField genreField = new JTextField(15);
        JTextField yearField = new JTextField(5);
        JTextField ratingField = new JTextField(4);
        JTextField revenueField = new JTextField(10);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2));
        panel.add(new JLabel("ID:"));
        panel.add(idField);
        panel.add(new JLabel("Title:"));
        panel.add(titleField);
        panel.add(new JLabel("Genre:"));
        panel.add(genreField);
        panel.add(new JLabel("Year:"));
        panel.add(yearField);
        panel.add(new JLabel("Rating (0-10):"));
        panel.add(ratingField);
        panel.add(new JLabel("Box Office Revenue:"));
        panel.add(revenueField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Add New Movie", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                // Retrieve input values with validation
                String movieID = idField.getText().trim();
                String title = titleField.getText().trim();
                String genre = genreField.getText().trim();
                int releaseYear = Integer.parseInt(yearField.getText().trim());
                double rating = Double.parseDouble(ratingField.getText().trim());
                String boxOfficeRevenue = revenueField.getText().trim();

                // Input Validation
                if (movieID.isEmpty() || title.isEmpty() || genre.isEmpty() || boxOfficeRevenue.isEmpty()) {
                    throw new IllegalArgumentException("Fields cannot be empty.");
                }
                if (releaseYear < 1888 || releaseYear > 2100) { // Realistic year range
                    throw new IllegalArgumentException("Year must be between 1888 and 2100.");
                }
                if (rating < 0 || rating > 10) {
                    throw new IllegalArgumentException("Rating must be between 0 and 10.");
                }


                // Add the movie if all fields are valid
                Movie movie = new Movie(movieID, title, genre, releaseYear, rating, boxOfficeRevenue);
                movies.add(movie);
                model.addRow(new Object[]{movieID, title, genre, releaseYear, rating, boxOfficeRevenue});

                JOptionPane.showMessageDialog(this, "Movie added successfully!");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers for Year, Rating, and Revenue.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void removeMovieDialog() {
        // Remove movie by title or genre
        String[] options = {"Title", "Genre"};
        String choice = (String) JOptionPane.showInputDialog(this, "Remove by:", "Remove Movie", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        if (choice != null) {
            String value = JOptionPane.showInputDialog(this, "Enter " + choice + ":");
            if (value != null && !value.trim().isEmpty()) {
                value = value.trim();
                ArrayList<Movie> moviesToRemove = new ArrayList<>();

                for (Movie movie : movies) {
                    if ((choice.equals("Title") && movie.getTitle().equalsIgnoreCase(value))
                            || (choice.equals("Genre") && movie.getGenre().equalsIgnoreCase(value))) {
                        moviesToRemove.add(movie);
                    }
                }

                if (!moviesToRemove.isEmpty()) {
                    movies.removeAll(moviesToRemove);
                    refreshTable();
                    JOptionPane.showMessageDialog(this, moviesToRemove.size() + " movie(s) removed successfully.");
                } else {
                    JOptionPane.showMessageDialog(this, "No movies found with the given " + choice.toLowerCase() + ".");
                }
            }
        }
    }

    private void batchUploadMovies() {
        // File chooser for selecting a text file
        JFileChooser fileChooser = new JFileChooser();
        int option = fileChooser.showOpenDialog(this);
        if (option == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                int addedCount = 0;
                int duplicateCount = 0;

                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data.length == 6) {
                        try {
                            String id = data[0].trim();
                            String title = data[1].trim();
                            String genre = data[2].trim();
                            int year = Integer.parseInt(data[3].trim());
                            double rating = Double.parseDouble(data[4].trim());
                            String revenue = data[5].trim(); // Round revenue to nearest integer

                            if (year >= 1888 && year <= 2100 && rating >= 0 && rating <= 10) {
                                // Check if the movie ID or title already exists
                                boolean exists = movies.stream().anyMatch(movie -> movie.getMovieID().equals(id) || movie.getTitle().equalsIgnoreCase(title));
                                if (!exists) {
                                    Movie movie = new Movie(id, title, genre, year, rating, revenue);
                                    movies.add(movie);
                                    addedCount++;
                                } else {
                                    duplicateCount++;
                                }
                            }
                        } catch (NumberFormatException e) {
                            // Ignore lines with invalid data formats
                        }
                    }
                }
                refreshTable();
                JOptionPane.showMessageDialog(this, addedCount + " movie(s) added successfully from the file.\n" +
                        duplicateCount + " duplicate movie(s) skipped.");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error reading the file.", "File Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void calculateAverageRating() {
        if (movies.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No movies to calculate.");
            return;
        }
        double totalRating = movies.stream().mapToDouble(Movie::getRating).sum();
        double averageRating = totalRating / movies.size();
        JOptionPane.showMessageDialog(this, "Average Rating: " + averageRating);
    }

    private void refreshTable() {
        // Clears and repopulates the table with the updated movie list
        model.setRowCount(0);
        for (Movie movie : movies) {
            model.addRow(new Object[]{
                    movie.getMovieID(),
                    movie.getTitle(),
                    movie.getGenre(),
                    movie.getReleaseYear(),
                    movie.getRating(),
                    movie.getBoxOfficeRevenue()
            });
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::new);
    }
}

